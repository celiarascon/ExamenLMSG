// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCZgo5PGnMHvw5HS0fFqPj4RMe1LSmcbjM",
    authDomain: "examenlmsg.firebaseapp.com",
    projectId: "examenlmsg",
    storageBucket: "examenlmsg.appspot.com",
    messagingSenderId: "539628147693",
    appId: "1:539628147693:web:6b9f92e96d0619f8190de4"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Initialize Cloud Firestore
const db = firebase.firestore();

// Obtener elementos del DOM
const formAlumno = document.getElementById('form-alumno');
const listaAlumnos = document.getElementById('lista-alumnos');

// Función para agregar un alumno a Firestore
function agregarAlumno(nombre, apellidos, dni, telefono) {
    return db.collection("alumnos").add({
        nombre,
        apellidos,
        dni,
        telefono,
        presente: false
    });
}

// Función para mostrar los datos de un alumno en la tabla
function mostrarAlumnoEnTabla(doc) {
    const alumno = doc.data();
    const tr = document.createElement('tr');
    tr.setAttribute('data-id', doc.id);

    tr.innerHTML = `
        <td><img src="https://api.multiavatar.com/${alumno.nombre}.png" alt="Avatar"></td>
        <td>${alumno.nombre}</td>
        <td>${alumno.apellidos}</td>
        <td>${alumno.dni}</td>
        <td>${alumno.telefono}</td>
        <td>
            <button class="btn-presente">${alumno.presente ? 'Presente' : 'Marcar Presente'}</button>
            <button class="btn-eliminar">Eliminar</button>
        </td>
    `;

    listaAlumnos.appendChild(tr);

    // Evento para marcar como presente
    tr.querySelector('.btn-presente').addEventListener('click', () => {
        const nuevoEstado = !alumno.presente;
        db.collection("alumnos").doc(doc.id).update({ presente: nuevoEstado });
    });

    // Evento para eliminar alumno
    tr.querySelector('.btn-eliminar').addEventListener('click', () => {
        db.collection("alumnos").doc(doc.id).delete();
    });
}

// Obtener y mostrar los datos de los alumnos desde Firestore
db.collection("alumnos").onSnapshot(snapshot => {
    listaAlumnos.innerHTML = '';
    snapshot.forEach(doc => mostrarAlumnoEnTabla(doc));
});

// Evento de submit del formulario
formAlumno.addEventListener('submit', function (e) {
    e.preventDefault();

    const nombre = formAlumno.nombre.value.trim();
    const apellidos = formAlumno.apellidos.value.trim();
    const dni = formAlumno.dni.value.trim();
    const telefono = formAlumno.telefono.value.trim();

    if (nombre && apellidos && dni && telefono) {
        agregarAlumno(nombre, apellidos, dni, telefono).then(() => {
            formAlumno.reset();
        });
    }
});
